# src/quality/validation.py
import pandas as pd
from great_expectations.core.expectation_suite import ExpectationSuite
from great_expectations.expectations.expectation_configuration import (
    ExpectationConfiguration,
)

RAW_DATA_PATH = "data/raw/patients_raw.csv"


def build_patient_expectation_suite() -> ExpectationSuite:
    """
    Tạo expectation suite cho anonymized patient data.
    """
    suite = ExpectationSuite(name="patient_data_suite")
    expectations = [
        ExpectationConfiguration(
            type="expect_column_values_to_not_be_null",
            kwargs={"column": "patient_id"},
        ),
        ExpectationConfiguration(
            type="expect_column_value_lengths_to_equal",
            kwargs={"column": "cccd", "value": 12},
        ),
        ExpectationConfiguration(
            type="expect_column_values_to_be_between",
            kwargs={"column": "ket_qua_xet_nghiem", "min_value": 0, "max_value": 50},
        ),
        ExpectationConfiguration(
            type="expect_column_values_to_be_in_set",
            kwargs={
                "column": "benh",
                "value_set": ["Tiểu đường", "Huyết áp cao", "Tim mạch", "Khỏe mạnh"],
            },
        ),
        ExpectationConfiguration(
            type="expect_column_values_to_match_regex",
            kwargs={
                "column": "email",
                "regex": r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$",
            },
        ),
        ExpectationConfiguration(
            type="expect_column_values_to_be_unique",
            kwargs={"column": "patient_id"},
        ),
    ]

    for expectation in expectations:
        suite.add_expectation_configuration(expectation)

    return suite


def _fail(results: dict, message: str) -> None:
    results["success"] = False
    results["failed_checks"].append(message)


def validate_anonymized_data(filepath: str) -> dict:
    """
    Validate anonymized data.
    Trả về dict: {"success": bool, "failed_checks": list, "stats": dict}
    """
    df = pd.read_csv(filepath, dtype={"cccd": str, "so_dien_thoai": str})
    results = {
        "success": True,
        "failed_checks": [],
        "stats": {
            "total_rows": len(df),
            "columns": list(df.columns),
        },
    }

    required_columns = [
        "patient_id",
        "ho_ten",
        "cccd",
        "so_dien_thoai",
        "email",
        "benh",
        "ket_qua_xet_nghiem",
    ]
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        _fail(results, f"Missing required columns: {', '.join(missing_columns)}")
        return results

    for col in ["patient_id", "benh", "ket_qua_xet_nghiem"]:
        if df[col].isnull().any():
            _fail(results, f"Null values in {col}")

    valid_benh = ["Tiểu đường", "Huyết áp cao", "Tim mạch", "Khỏe mạnh"]
    if not df["benh"].isin(valid_benh).all():
        _fail(results, "Invalid disease values")

    if not df["ket_qua_xet_nghiem"].between(0, 50).all():
        _fail(results, "Lab results outside expected range [0, 50]")

    if df["patient_id"].duplicated().any():
        _fail(results, "Duplicate patient_id values")

    if not df["cccd"].astype(str).str.fullmatch(r"\d{12}").all():
        _fail(results, "Anonymized CCCD values must be 12 digits")

    if not df["so_dien_thoai"].astype(str).str.fullmatch(r"0[35789]\d{8}").all():
        _fail(results, "Anonymized phone values must match VN mobile format")

    try:
        original_df = pd.read_csv(RAW_DATA_PATH, dtype={"cccd": str, "so_dien_thoai": str})
    except FileNotFoundError:
        original_df = None

    if original_df is not None:
        if len(df) != len(original_df):
            _fail(results, "Row count does not match original raw data")

        raw_cccd = set(original_df["cccd"].astype(str))
        anonymized_cccd = set(df["cccd"].astype(str))
        if raw_cccd & anonymized_cccd:
            _fail(results, "Original CCCD values still present after anonymization")

    return results
