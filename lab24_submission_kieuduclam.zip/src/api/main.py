# src/api/main.py
from pathlib import Path

from fastapi import Depends, FastAPI
import pandas as pd
from src.access.rbac import get_current_user, require_permission
from src.pii.anonymizer import MedVietAnonymizer

app = FastAPI(title="MedViet Data API", version="1.0.0")
anonymizer = MedVietAnonymizer()
PROJECT_ROOT = Path(__file__).resolve().parents[2]
RAW_PATIENTS_PATH = PROJECT_ROOT / "data" / "raw" / "patients_raw.csv"

# --- ENDPOINT 1 ---
@app.get("/api/patients/raw")
@require_permission(resource="patient_data", action="read")
async def get_raw_patients(
    current_user: dict = Depends(get_current_user)
):
    """Trả về raw patient data (chỉ admin được phép)."""
    df = pd.read_csv(RAW_PATIENTS_PATH)
    return {"data": df.head(10).to_dict("records"), "user": current_user["username"]}

# --- ENDPOINT 2 ---
@app.get("/api/patients/anonymized")
@require_permission(resource="training_data", action="read")
async def get_anonymized_patients(
    current_user: dict = Depends(get_current_user)
):
    """Trả về anonymized data (ml_engineer và admin được phép)."""
    df = pd.read_csv(RAW_PATIENTS_PATH)
    df_anon = anonymizer.anonymize_dataframe(df.head(10))
    return {"data": df_anon.to_dict("records"), "user": current_user["username"]}

# --- ENDPOINT 3 ---
@app.get("/api/metrics/aggregated")
@require_permission(resource="aggregated_metrics", action="read")
async def get_aggregated_metrics(
    current_user: dict = Depends(get_current_user)
):
    """Trả về aggregated metrics (data_analyst, ml_engineer, admin)."""
    df = pd.read_csv(RAW_PATIENTS_PATH)
    metrics = df["benh"].value_counts().to_dict()
    return {
        "disease_counts": metrics,
        "total_patients": int(len(df)),
        "average_lab_result": float(df["ket_qua_xet_nghiem"].mean()),
        "user": current_user["username"],
    }

# --- ENDPOINT 4 ---
@app.delete("/api/patients/{patient_id}")
@require_permission(resource="patient_data", action="delete")
async def delete_patient(
    patient_id: str,
    current_user: dict = Depends(get_current_user)
):
    """Chỉ admin được xóa. Các role khác nhận 403."""
    return {"deleted": patient_id, "user": current_user["username"]}

@app.get("/health")
async def health():
    return {"status": "ok", "service": "MedViet Data API"}
