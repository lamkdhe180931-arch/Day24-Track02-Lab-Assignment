import secrets

import pandas as pd
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig
from faker import Faker
from .detector import build_vietnamese_analyzer, detect_pii

fake = Faker("vi_VN")


def fake_cccd() -> str:
    return "".join(str(secrets.randbelow(10)) for _ in range(12))


def fake_vn_phone() -> str:
    return "0" + secrets.choice("35789") + "".join(
        str(secrets.randbelow(10)) for _ in range(8)
    )


class MedVietAnonymizer:

    def __init__(self):
        self.analyzer = build_vietnamese_analyzer()
        self.anonymizer = AnonymizerEngine()

    def anonymize_text(self, text: str, strategy: str = "replace") -> str:
        """
        Anonymize text với strategy được chọn.

        Strategies:
        - "mask"    : Nguyen Van A → N****** V** A
        - "replace" : thay bằng fake data (dùng Faker)
        - "hash"    : SHA-256 one-way hash
        - "generalize": chỉ dùng cho tuổi/năm sinh
        """
        results = detect_pii(text, self.analyzer)
        if not results:
            return text

        operators = {}

        if strategy == "replace":
            operators = {
                "PERSON": OperatorConfig("replace",
                          {"new_value": fake.name()}),
                "EMAIL_ADDRESS": OperatorConfig("replace",
                                 {"new_value": fake.email()}),
                "VN_CCCD": OperatorConfig("replace",
                           {"new_value": fake_cccd()}),
                "VN_PHONE": OperatorConfig("replace",
                            {"new_value": fake_vn_phone()}),
            }
        elif strategy == "mask":
            operators = {
                entity: OperatorConfig(
                    "mask",
                    {
                        "masking_char": "*",
                        "chars_to_mask": 100,
                        "from_end": False,
                    },
                )
                for entity in ["PERSON", "EMAIL_ADDRESS", "VN_CCCD", "VN_PHONE"]
            }
        elif strategy == "hash":
            operators = {
                entity: OperatorConfig("hash", {"hash_type": "sha256"})
                for entity in ["PERSON", "EMAIL_ADDRESS", "VN_CCCD", "VN_PHONE"]
            }
        else:
            raise ValueError(f"Unsupported anonymization strategy: {strategy}")

        anonymized = self.anonymizer.anonymize(
            text=text,
            analyzer_results=results,
            operators=operators
        )
        return anonymized.text

    def anonymize_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Anonymize toàn bộ DataFrame.
        - Cột text (ho_ten, dia_chi, email): dùng anonymize_text()
        - Cột cccd, so_dien_thoai: replace trực tiếp bằng fake data
        - Cột benh, ket_qua_xet_nghiem: GIỮ NGUYÊN (cần cho model training)
        - Cột patient_id: GIỮ NGUYÊN (pseudonym đã đủ an toàn)
        """
        df_anon = df.copy()

        # Text columns: anonymize
        if "ho_ten" in df_anon.columns:
            df_anon["ho_ten"] = df_anon["ho_ten"].apply(
                lambda x: self.anonymize_text(str(x), strategy="replace")
            )
        if "dia_chi" in df_anon.columns:
            df_anon["dia_chi"] = df_anon["dia_chi"].apply(
                lambda x: self.anonymize_text(str(x), strategy="replace")
            )
        if "email" in df_anon.columns:
            df_anon["email"] = df_anon["email"].apply(
                lambda x: self.anonymize_text(str(x), strategy="replace")
            )

        # Direct replacement columns
        if "cccd" in df_anon.columns:
            original_cccd = set(df["cccd"].astype(str))
            replacements = []
            while len(replacements) < len(df_anon):
                candidate = fake_cccd()
                if candidate not in original_cccd and candidate not in replacements:
                    replacements.append(candidate)
            df_anon["cccd"] = replacements
        if "so_dien_thoai" in df_anon.columns:
            df_anon["so_dien_thoai"] = [fake_vn_phone() for _ in range(len(df_anon))]

        return df_anon

    def calculate_detection_rate(self, 
                                  original_df: pd.DataFrame,
                                  pii_columns: list) -> float:
        """
        Tính % PII được detect thành công.
        Mục tiêu: > 95%

        Logic: với mỗi ô trong pii_columns,
               kiểm tra xem detect_pii() có tìm thấy ít nhất 1 entity không.
        """
        total = 0
        detected = 0

        for col in pii_columns:
            for value in original_df[col].astype(str):
                total += 1
                results = detect_pii(value, self.analyzer)
                if len(results) > 0:
                    detected += 1

        return detected / total if total > 0 else 0.0
