# NĐ13/2023 Compliance Checklist - MedViet AI Platform

## A. Data Localization
- [x] Patient data is stored in the local MedViet data store for this lab; production deployment must pin primary storage to Vietnam regions.
- [x] Backups must use Vietnam-hosted object storage with encrypted snapshots and retention policies.
- [x] Cross-border transfer attempts are governed by OPA policy and must be logged before approval.

## B. Explicit Consent
- [x] Consent must be collected before using patient records for AI training.
- [x] Withdrawal requests must trigger removal from future training datasets and regenerate processed anonymized data.
- [x] Consent records must store patient_id, purpose, timestamp, consent version, and withdrawal timestamp when applicable.

## C. Breach Notification (72h)
- [x] Incident response plan: detect, contain, assess affected data, notify DPO, notify authority within 72 hours when required.
- [x] Prometheus/Grafana alerting will monitor anomalous API access, repeated 403/401 responses, and unexpected export attempts.
- [x] Audit evidence must include timeline, impacted records, containment actions, and notification status.

## D. DPO Appointment
- [x] Data Protection Officer appointed for the platform.
- [x] DPO contact: dpo@medviet.example

## E. Technical Controls (mapping from requirements)
| NĐ13 Requirement | Technical Control | Status | Owner |
|-----------------|-------------------|--------|-------|
| Data minimization | PII anonymization pipeline with Vietnamese Presidio recognizers and processed training CSV | Done | AI Team |
| Access control | RBAC with Casbin plus ABAC/export rules in OPA | Done | Platform Team |
| Encryption | AES-256-GCM envelope encryption via `SimpleVault`; production KEK must move to KMS/HSM; TLS 1.3 at ingress | Done for lab | Infra Team |
| Audit logging | FastAPI access logs, auth decision logs, immutable centralized log sink, and retention policy | Designed | Platform Team |
| Breach detection | Prometheus metrics, Grafana dashboard, alert rules for suspicious access/export patterns | Designed | Security Team |

## F. Technical Solutions For Open Controls

### Audit Logging
- Emit structured JSON logs for every API request with timestamp, username, role, resource, action, decision, status code, and request_id.
- Send logs to a centralized append-only sink such as CloudWatch/CloudTrail equivalent or an on-prem SIEM hosted in Vietnam.
- Add alert queries for spikes in denied requests, raw PII access, delete requests, and restricted export attempts.

### Breach Detection
- Track authentication failures, RBAC denials, delete attempts, export attempts, and volume anomalies with Prometheus counters.
- Configure Grafana alerts to notify Security and DPO channels when thresholds are exceeded.
- Keep incident runbooks linked to dashboards so the 72-hour notification process can start immediately.

### Encryption Hardening
- Replace local `.vault_key` with production KMS/HSM-managed KEK.
- Rotate KEKs on schedule and after suspected exposure.
- Encrypt raw and processed data at rest, require TLS 1.3 for all API traffic, and deny plaintext data exports.
