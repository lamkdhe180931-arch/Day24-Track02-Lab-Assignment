from pathlib import Path

import pandas as pd
from fastapi.testclient import TestClient

from src.access.rbac import enforcer
from src.api.main import app
from src.encryption.vault import SimpleVault
from src.quality.validation import validate_anonymized_data


def test_rbac_role_permissions_match_lab_requirements():
    assert enforcer.enforce("admin", "patient_data", "read")
    assert enforcer.enforce("admin", "training_data", "read")
    assert enforcer.enforce("admin", "aggregated_metrics", "read")
    assert not enforcer.enforce("ml_engineer", "patient_data", "read")
    assert enforcer.enforce("ml_engineer", "training_data", "read")
    assert enforcer.enforce("ml_engineer", "aggregated_metrics", "read")
    assert enforcer.enforce("data_analyst", "aggregated_metrics", "read")
    assert not enforcer.enforce("intern", "patient_data", "read")


def test_api_enforces_roles_and_returns_expected_payloads():
    client = TestClient(app)

    raw_denied = client.get(
        "/api/patients/raw",
        headers={"Authorization": "Bearer token-bob"},
    )
    assert raw_denied.status_code == 403

    raw_allowed = client.get(
        "/api/patients/raw",
        headers={"Authorization": "Bearer token-alice"},
    )
    assert raw_allowed.status_code == 200
    assert len(raw_allowed.json()["data"]) == 10

    anonymized = client.get(
        "/api/patients/anonymized",
        headers={"Authorization": "Bearer token-bob"},
    )
    assert anonymized.status_code == 200
    assert len(anonymized.json()["data"]) == 10

    metrics = client.get(
        "/api/metrics/aggregated",
        headers={"Authorization": "Bearer token-carol"},
    )
    assert metrics.status_code == 200
    assert "disease_counts" in metrics.json()


def test_encryption_round_trip_and_payload_shape(tmp_path):
    vault = SimpleVault(master_key_path=str(tmp_path / ".vault_key"))
    original = "Nguyen Van A - CCCD: 012345678901"

    encrypted = vault.encrypt_data(original)
    assert encrypted["algorithm"] == "AES-256-GCM"
    assert encrypted["ciphertext"] != original
    assert vault.decrypt_data(encrypted) == original


def test_validate_anonymized_data_detects_safe_processed_file(tmp_path):
    df = pd.read_csv("data/raw/patients_raw.csv")
    processed = df.copy()
    processed["cccd"] = [f"9{i:011d}" for i in range(len(processed))]
    processed["so_dien_thoai"] = [f"09{i:08d}" for i in range(len(processed))]
    path = tmp_path / "patients_anonymized.csv"
    processed.to_csv(path, index=False)

    result = validate_anonymized_data(str(path))

    assert result["success"] is True
    assert result["stats"]["total_rows"] == len(df)
    assert result["failed_checks"] == []


def test_opa_policy_contains_restricted_role_rules():
    policy = Path("policies/opa_policy.rego").read_text()

    assert 'input.resource == "aggregated_metrics"' in policy
    assert 'input.resource == "reports"' in policy
    assert 'input.resource == "sandbox_data"' in policy
    assert 'input.resource == "production_data"' in policy
    assert 'destination_country != "VN"' in policy
